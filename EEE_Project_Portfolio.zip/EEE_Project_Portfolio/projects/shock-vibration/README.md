# Arduino Shock / Vibration Detection

An Arduino Uno experiment using a shock/vibration switch and buzzer.

## Work explored
- Tested the switch and buzzer independently
- Integrated both with Arduino
- Debugged continuous and missing buzzer responses by checking signal readings and connections

## To add
- Sketch/source code
- Wiring photo or circuit diagram
- Sensor output observations

**Status:** Working experiment; further documentation can be added.
