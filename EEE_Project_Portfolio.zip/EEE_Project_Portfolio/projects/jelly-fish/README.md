# Jelly Fish — Bookmark Manager

A browser-based bookmark manager made with HTML, CSS and JavaScript.

## Structure
- `index.html`
- `style.css`
- `script.js`

## Notes
The project used browser `localStorage` to save bookmarks locally. Data is stored per browser/device.

**Status:** Add the original source files here before treating this folder as a complete code release.
