# AtmosMapper — Drone-Based Gas Monitoring

A drone-oriented gas-monitoring project using gas sensors, GPS logging and an ESP32-based data link.

## Work explored
- MQ-series gas sensor readings
- GPS path logging
- ESP32 wireless communication using UDP
- Python dashboard for sensor readings and mapped locations

## To add
- Original firmware and Python code
- Wiring diagrams
- Drone and sensor photographs
- Sample CSV/log files
- Demo video

**Status:** Hardware/system integration was explored. Add only verified code and results.
