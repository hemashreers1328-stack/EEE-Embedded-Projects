# Obstacle-Avoiding Robot — Planned

## Learning/build sequence
1. Learn basic robotics and the role of each component.
2. Understand the motor driver, motors, controller and power supply.
3. Build and test basic movement.
4. Add obstacle-detection sensors.
5. Make the robot react to detected obstacles.
6. Test and improve its behaviour.

**Status:** Planned idea; no completed robot is claimed here.
