# EEE & Embedded Systems Project Portfolio

A collection of my electronics, embedded-systems, and software projects and experiments.

> **Note:** This portfolio separates hands-on work from ideas and ongoing learning. Some entries are experiments or project concepts, not completed products. Code, circuit photos, CAD files, and videos can be added as they are documented.

## Hands-on projects and experiments

### 1. AtmosMapper — Drone-Based Gas Monitoring
- **Platforms:** ESP32, Python
- **Hardware explored:** MQ-series gas sensors (including MQ-2, MQ-4, MQ-6 and MQ-135), GPS, distance sensors and camera integration.
- **Work:** Gas-sensor readings, GPS-based path logging, ESP32-to-ESP32 wireless communication using UDP, and a Python dashboard for displaying readings and locations.
- **Status:** Hardware and system integration were explored; project documentation and code should be added.

### 2. Arduino Shock / Vibration Detection
- **Platform:** Arduino Uno
- **Hardware:** Shock/vibration switch and buzzer.
- **Work:** Tested the sensor and buzzer separately, then debugged their combined behaviour and signal readings.
- **Status:** Working experiment; further refinement and circuit documentation can be added.

### 3. Arduino Sensor Experiments
- **Platform:** Arduino Uno
- **Modules explored:** Flame sensor, DHT11, MPU6050, HC-SR04 ultrasonic sensor, joystick, LEDs and buzzer.
- **Work:** Individual module testing and basic input/output experiments.
- **Status:** Learning experiments; add a separate circuit/code folder for each completed build.

### 4. Arduino Joystick Mouse
- **Platform:** Arduino Uno + Python
- **Software/libraries:** PySerial and PyAutoGUI.
- **Work:** Used joystick input from Arduino to control mouse movement on a computer.
- **Status:** Prototype/experiment.

### 5. Jelly Fish — Bookmark Manager
- **Technologies:** HTML, CSS and JavaScript.
- **Work:** Built a browser-based bookmark manager using localStorage, with a simple folder/link organisation concept.
- **Status:** Project structure was developed; add the original source files and screenshots.

## Ongoing learning and project development

### 6. Renesas RA6E2 — Industrial Machine Monitoring Concept
- **Platform:** Renesas RA6E2 Quick Connect Beginner Kit.
- **Concept:** A fixed monitoring unit for industrial environments that collects machine and environmental sensor data, detects abnormal conditions and gas leaks, and helps identify possible equipment faults.
- **Status:** Project concept and system planning; do not treat as a completed implementation.

### 7. YOLOv8n + VisDrone
- **Technologies:** Python, YOLOv8n and VisDrone dataset.
- **Work:** Explored an object-detection workflow and setup.
- **Status:** Experiment; dataset and installation issues were encountered.

### 8. RISC-V MCU on Sipeed Tang Primer 25K
- **Platform:** Sipeed Tang Primer 25K FPGA.
- **Concept:** Explore a compact RISC-V microcontroller implementation within the FPGA's resource limits.
- **Status:** Design/learning idea, not a verified completed implementation.

## Planned idea

### 9. Obstacle-Avoiding Robot
- **Concept:** Learn the basics of robotics, understand the required components, build basic movement first, then add obstacle-detection sensors and make the robot react to what it detects.
- **Status:** Planned; not yet documented as a built robot.

## Skills and tools explored
- Microcontrollers: Arduino Uno, ESP32, Wemos D1 Mini, Renesas RA6E2
- Sensors and modules: gas sensors, GPS, vibration switch, flame sensor, DHT11, MPU6050, HC-SR04, servo, buzzer, MAX485
- Software: Python, C/C++ basics, HTML, CSS, JavaScript
- Communication: UART/serial, Wi-Fi and UDP
- Tools: VS Code, PlatformIO, LTspice, KiCad, Tinkercad

## Documentation to add
- [ ] Original source code
- [ ] Circuit diagrams and wiring photos
- [ ] Hardware photographs
- [ ] Demo videos
- [ ] Test results and observations

Only add files that are your own work and label unfinished experiments honestly.
